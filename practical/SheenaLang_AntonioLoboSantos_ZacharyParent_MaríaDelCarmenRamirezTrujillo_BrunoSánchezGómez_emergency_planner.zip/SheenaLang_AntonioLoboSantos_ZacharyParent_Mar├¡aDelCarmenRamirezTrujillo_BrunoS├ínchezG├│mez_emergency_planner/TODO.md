# TODO

## By *2024-10-23*

- (@everyone)
    - [ ] read the [instructions](references/MAS-practical_work_24-25_presencial_v2.pdf)
    - [ ] read the [README](README.md) for an explanation of the repo structure
    - [ ] brainstorm locations to use for the practical work
    - [ ] consider what portion of the report you would like to work on

## By final submission
- () [ ] add jordi.pascual@urv.cat to the git repo
